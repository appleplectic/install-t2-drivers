The files go to:
- /usr/share/alsa/cards/AppleT2.conf
- /usr/share/pulseaudio/alsa-mixer/profile-sets/apple-t2.conf
- /usr/lib/udev/rules.d/91-pulseaudio-custom.rules