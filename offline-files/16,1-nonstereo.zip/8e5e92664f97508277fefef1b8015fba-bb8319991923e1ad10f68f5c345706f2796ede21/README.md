The files go to:

* /usr/share/alsa/cards/AppleT2.conf
* /usr/share/pulseaudio/alsa-mixer/profile-sets/apple-t2.conf
* /usr/lib/udev/rules.d/91-pulseaudio-custom.rules
* $HOME/.config/pulse/default.pa
* $HOME/.config/pulse/daemon.conf

The PulseAudio configuration in the home-directory is just an example. What I did was to add the following:

default.pa:
```
load-module module-combine-sink channels=6 channel_map=front-left,front-right,rear-left,rear-right,front-center,lfe
```

daemon.conf:
```
default-sample-channels = 6
enable-lfe-remixing = yes
```

Originally by MCMrARM (https://gist.github.com/MCMrARM/c357291e4e5c18894bea10665dcebffb)