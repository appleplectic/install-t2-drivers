The files go to:

* /usr/share/alsa/cards/AppleT2.conf
* /usr/share/pulseaudio/alsa-mixer/profile-sets/apple-t2.conf
* /usr/lib/udev/rules.d/91-pulseaudio-custom.rules
* $HOME/.config/pulse/default.pa
* $HOME/.config/pulse/daemon.conf

I configured the speakers as a stereo setup instead of a conventional 5.1 system. The result is a more consistent, clearer output.

Optional: Pair with an equalizer! I personally use the Laptop EQ from `pulseaudio-equalizer-ladspa`

Adapted from kevineinarsson (https://gist.github.com/kevineinarsson/8e5e92664f97508277fefef1b8015fba)
Originally by MCMrARM (https://gist.github.com/MCMrARM/c357291e4e5c18894bea10665dcebffb)