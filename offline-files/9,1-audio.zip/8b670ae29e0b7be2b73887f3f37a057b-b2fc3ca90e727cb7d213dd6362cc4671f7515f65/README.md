The files go to:
- /usr/share/alsa/cards/AppleT2.conf
- /usr/share/pulseaudio/alsa-mixer/profile-sets/apple-t2.conf
- /usr/lib/udev/rules.d/91-pulseaudio-custom.rules

I tweaked the settings to get it working for my MacbookAir9,1 (2020)
I'm on Fedora 34 with custom ISO linked here https://github.com/mikeeq/mbp-fedora
Have a read on https://t2linux.org and their wiki before changing anything.